﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;
using System.Threading.Tasks;
using System.IO;
using System.Text;
using System.Xml;
using System.Net;


namespace MediaSearch.BL
{

    public class WebServiceManager
    {
        private static string _url;
        private static string _action;

        public WebServiceManager(string url, string action) {
            _url = url;
            _action = action;
        }
        public static void CallWebService()
        {            

            XmlDocument soapEnvelopeXml = CreateSoapEnvelope();
            HttpWebRequest webRequest = CreateWebRequest(_url, _action);
            InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXml, webRequest);

            IAsyncResult asyncResult = webRequest.BeginGetResponse(null, null);

            asyncResult.AsyncWaitHandle.WaitOne();

            string soapResult;
            using (WebResponse webResponse = webRequest.EndGetResponse(asyncResult))
            {
                using (StreamReader rd = new StreamReader(webResponse.GetResponseStream()))
                {
                    soapResult = rd.ReadToEnd();
                }
                Console.Write(soapResult);
            }
        }

        private static HttpWebRequest CreateWebRequest(string url, string action)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Headers.Add("SOAPAction", action);
            webRequest.ContentType = "text/xml;charset=\"utf-8\"";
            webRequest.Accept = "text/xml";
            webRequest.Method = "POST";
            return webRequest;
        }

        private static XmlDocument CreateSoapEnvelope()
        {
            XmlDocument soapEnvelopeDocument = new XmlDocument();
            soapEnvelopeDocument.LoadXml(
            @"<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" 
               xmlns:xsi=""http://www.w3.org/1999/XMLSchema-instance"" 
               xmlns:xsd=""http://www.w3.org/1999/XMLSchema"">
        <SOAP-ENV:Body>
            <HelloWorld xmlns=""http://tempuri.org/"" 
                SOAP-ENV:encodingStyle=""http://schemas.xmlsoap.org/soap/encoding/"">
                <int1 xsi:type=""xsd:integer"">12</int1>
                <int2 xsi:type=""xsd:integer"">32</int2>
            </HelloWorld>
        </SOAP-ENV:Body>
    </SOAP-ENV:Envelope>");
            return soapEnvelopeDocument;
        }

        private static void InsertSoapEnvelopeIntoWebRequest(XmlDocument soapEnvelopeXml, HttpWebRequest webRequest)
        {
            using (Stream stream = webRequest.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }
        }
    }
    public class Utilities
    {
        public string splitTerms(string searchTerm, string joiner="+")
        {
            string[] listOfTerms = searchTerm.Split('_');
            if (listOfTerms.Length > 1)
            {
                string newSearchTerms = String.Join(joiner, listOfTerms);
                return newSearchTerms;
            }
            else
            {
                return searchTerm;
            }
        }

        public string OnlyCurl(string URLStr)
        {
            using (var client = new HttpClient())
            {
                var response = client.GetAsync(URLStr).Result;

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = response.Content;
                    string responseString = responseContent.ReadAsStringAsync().Result;

                    return responseString;
                }
            }
            return String.Empty;
        }
    }
    public class Invoker
    {
        Utilities utils = new Utilities();
        private string iTunesCurl(string searchTerm, string typeOfSearch)
        {            
            string URLStr = String.Format("https://itunes.apple.com/search?term={0}&media={1}", searchTerm, typeOfSearch);
            return utils.OnlyCurl(URLStr);
        }

        private string TVMazeCurl(string searchTerm)
        {
            string URLStr = String.Format("http://api.tvmaze.com/search/shows?q={0}", searchTerm);
            return utils.OnlyCurl(URLStr);
        }

        private string crcindCurl(string searchTerm) {        
            string URLStr = String.Format("http://www.crcind.com/csp/samples/SOAP.Demo.cls?soap_method=QueryByName&name={0}", searchTerm);
            return utils.OnlyCurl(URLStr);
        }
        public string songs(string searchTerm) {
            var newSearchTerm = utils.splitTerms(searchTerm);
            return iTunesCurl(newSearchTerm, "music");
        }

        public string movies(string searchTerm) {
            var newSearchTerm = utils.splitTerms(searchTerm);
            return iTunesCurl(newSearchTerm, "movie");
        }

        public string shows(string searchTerm) {
            var newSearchTerm = utils.splitTerms(searchTerm, "%20");
            return TVMazeCurl(newSearchTerm);
        }

        public string persons(string searchTerm) {
            var newSearchTerm = utils.splitTerms(searchTerm, "%20");
            return crcindCurl(newSearchTerm);
        }
    }
}