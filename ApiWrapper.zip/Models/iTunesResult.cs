﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MediaSearch.Models
{
    public class ITunesResult
    {
        private string wrapperType;
        private string kind;
        private int artistId;
        private int collectionId;
        private string artistName;

    }
}