﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MediaSearch.BL;

namespace MediaSearch.Controllers
{
    [RoutePrefix("api/values")]
    public class ValuesController : ApiController
    {
        private Invoker inv;
        
        // GET api/values/canciones
        [HttpGet]
        [Route("canciones/{searchTerm}")]
        public string Get(string searchTerm)
        {
            var inv = new Invoker();
            var myResponse = inv.songs(searchTerm);
            return myResponse;
        }

        // GET api/values/peliculas
        [HttpGet]
        [Route("peliculas/{searchTerm}")]
        public string GetM(string searchTerm)
        {
            var inv = new Invoker();
            var myResponse = inv.movies(searchTerm);
            return myResponse;
        }

        // GET api/values/showsdetelevision
        [HttpGet]
        [Route("showsdetelevision/{searchTerm}")]
        public string GetS(string searchTerm)
        {
            var inv = new Invoker();
            var myResponse = inv.shows(searchTerm);
            return myResponse;
        }

        // GET api/values/personas
        [HttpGet]
        [Route("personas/{searchTerm}")]
        public string GetP(string searchTerm)
        {
            var inv = new Invoker();
            var myResponse = inv.shows(searchTerm);
            return myResponse;
        }

        // no implementaremos nada acá
        // POST api/values
        public void Post([FromBody] string value)
        {
        }

        // no implementaremos nada acá
        // PUT api/values/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // no implementaremos nada acá
        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
